package Assignments;

public class DepositClass {
    public final int Value1;//variable to hold the deposit value

    public DepositClass (int Value) {// Constructor that initializes the deposit amount

        this.Value1 = Value;//
    }
}
