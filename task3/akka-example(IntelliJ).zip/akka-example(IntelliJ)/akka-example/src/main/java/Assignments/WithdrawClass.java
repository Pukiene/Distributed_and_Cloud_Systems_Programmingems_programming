package Assignments;

public class WithdrawClass {// Define the WithdrawClass which will serve as the withdrawal mesg

    public final  int Value1;//to hold the withdrawal value

    public WithdrawClass(int Value1) {//Constructor the withdrawal amount

        this.Value1 = Value1;//passed value to the Value1 variable
    }

}

