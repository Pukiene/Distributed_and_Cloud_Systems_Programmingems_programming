package com.example;

public class MessageA {
    public final String text;

    public MessageA(String text) {
        this.text = text;
    }
}

