package com.example;

public class MessageB {
    public final Integer number;

    public MessageB(Integer num) {
        this.number = num;
    }
}

